CREATE TABLE `Subscription` (
  `SubscriptionID` INT PRIMARY KEY AUTO_INCREMENT,
  `SubscriptionType` VARCHAR(50) UNIQUE NOT NULL,
  `Price` DECIMAL(5,2) NOT NULL
);

CREATE TABLE `Users` (
  `UserID` INT PRIMARY KEY AUTO_INCREMENT,
  `UserName` VARCHAR(100) NOT NULL,
  `FirstName` VARCHAR(200) NOT NULL,
  `LastName` VARCHAR(200) NOT NULL,
  `Email` VARCHAR(100) UNIQUE NOT NULL,
  `PasswordHash` VARCHAR(255) NOT NULL,
  `City` VARCHAR(100),
  `Country` VARCHAR(100),
  `Age` INT,
  `FavoriteListID` INT,
  `CreatedAt` DATETIME DEFAULT (current_timestamp),
  `UpdatedAt` DATETIME DEFAULT (current_timestamp)
);

CREATE TABLE `Plan` (
  `PlanID` INT PRIMARY KEY AUTO_INCREMENT,
  `UserID` INT,
  `SubscriptionID` int,
  `start_date` date,
  `end_date` date,
  `active_status` BINARY
);

CREATE TABLE `Category` (
  `CategoryID` INT PRIMARY KEY AUTO_INCREMENT,
  `CategoryName` VARCHAR(100) UNIQUE NOT NULL
);

CREATE TABLE `Video` (
  `VideoID` INT PRIMARY KEY AUTO_INCREMENT,
  `Title` VARCHAR(200) NOT NULL,
  `VideoDescription` TEXT,
  `Duration` INT NOT NULL,
  `ReleaseDate` DATE,
  `Movie_OR_Show` INT,
  `CategoryID` INT,
  `CreatedAt` DATETIME DEFAULT (current_timestamp),
  `UpdatedAt` DATETIME DEFAULT (current_timestamp)
);

CREATE TABLE `Review` (
  `ReviewID` INT PRIMARY KEY AUTO_INCREMENT,
  `UserID` INT,
  `VideoID` INT,
  `Rating` INT NOT NULL,
  `Comment` VARCHAR(500),
  `CreatedAt` DATETIME DEFAULT (current_timestamp),
  `UpdatedAt` DATETIME DEFAULT (current_timestamp),
   UNIQUE (user_id, video_id)
);

CREATE TABLE `Actor` (
  `ActorID` INT PRIMARY KEY AUTO_INCREMENT,
  `FirstName` VARCHAR(200) NOT NULL,
  `LastName` VARCHAR(200) NOT NULL,
  `City` VARCHAR(100),
  `Country` VARCHAR(100),
  `DOB` DATE,
  `Age` INT NOT NULL,
  `CreatedAt` DATETIME DEFAULT (current_timestamp),
  `UpdatedAt` DATETIME DEFAULT (current_timestamp)
);

CREATE TABLE `VideoActor` (
  `VideoID` INT,
  `ActorID` INT,
  `Role` VARCHAR(100),
  PRIMARY KEY (`VideoID`, `ActorID`)
);

CREATE TABLE `FavoriteList` (
  `FavoriteListID` INT PRIMARY KEY AUTO_INCREMENT,
  `UserID` INT NOT NULL,
  `CreatedAt` DATETIME DEFAULT (current_timestamp),
  `UpdatedAt` DATETIME DEFAULT (current_timestamp),
   UNIQUE (user_id)
);

CREATE TABLE `FavoriteListVideo` (
  `FavoriteListID` INT,
  `VideoID` INT
);

CREATE TABLE `WatchHistory` (
  `UserID` INT,
  `VideoID` INT,
  `WatchedDateTIme` Date,
  `WatchLength` Duration
);

CREATE INDEX `fk_favoritelistid` ON `Users` (`FavoriteListID`);

CREATE INDEX `fk_userid` ON `Review` (`UserID`);

CREATE INDEX `fk_videoid` ON `Review` (`VideoID`);

CREATE UNIQUE INDEX `UC_UserVideoReview` ON `Review` (`UserID`, `VideoID`);

CREATE INDEX `fk_userid` ON `FavoriteList` (`UserID`);

ALTER TABLE `Users` ADD FOREIGN KEY (`FavoriteListID`) REFERENCES `FavoriteList` (`FavoriteListID`);

ALTER TABLE `Video` ADD FOREIGN KEY (`CategoryID`) REFERENCES `Category` (`CategoryID`);

ALTER TABLE `Review` ADD FOREIGN KEY (`UserID`) REFERENCES `Users` (`UserID`);

ALTER TABLE `Review` ADD FOREIGN KEY (`VideoID`) REFERENCES `Video` (`VideoID`);

ALTER TABLE `VideoActor` ADD FOREIGN KEY (`VideoID`) REFERENCES `Video` (`VideoID`);

ALTER TABLE `VideoActor` ADD FOREIGN KEY (`ActorID`) REFERENCES `Actor` (`ActorID`);

ALTER TABLE `FavoriteList` ADD FOREIGN KEY (`UserID`) REFERENCES `Users` (`UserID`);

ALTER TABLE `FavoriteListVideo` ADD FOREIGN KEY (`FavoriteListID`) REFERENCES `FavoriteList` (`FavoriteListID`);

ALTER TABLE `FavoriteListVideo` ADD FOREIGN KEY (`VideoID`) REFERENCES `Video` (`VideoID`);

ALTER TABLE `Plan` ADD FOREIGN KEY (`SubscriptionID`) REFERENCES `Subscription` (`SubscriptionID`);

ALTER TABLE `Plan` ADD FOREIGN KEY (`UserID`) REFERENCES `Users` (`UserID`);

ALTER TABLE `Video` ADD FOREIGN KEY (`VideoID`) REFERENCES `WatchHistory` (`VideoID`);

ALTER TABLE `Users` ADD FOREIGN KEY (`UserID`) REFERENCES `WatchHistory` (`UserID`);
