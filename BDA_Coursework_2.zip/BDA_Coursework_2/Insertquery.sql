INSERT INTO `Subscription` (`SubscriptionType`, `Price`) VALUES ('HD', 12.00);
INSERT INTO `Subscription` (`SubscriptionType`, `Price`) VALUES ('UHD', 18.00);



users


INSERT INTO `Users` (`UserName`, `FirstName`, `LastName`, `Email`, `PasswordHash`, `City`, `Country`, `Age`)
VALUES ('john_doe', 'John', 'Doe', 'john.doe@example.com', 'hashed_password_1', 'New York', 'USA', 30);

INSERT INTO `Users` (`UserName`, `FirstName`, `LastName`, `Email`, `PasswordHash`, `City`, `Country`, `Age`)
VALUES ('alice_smith', 'Alice', 'Smith', 'alice.smith@example.com', 'hashed_password_2', 'London', 'UK', 25);

INSERT INTO `Users` (`UserName`, `FirstName`, `LastName`, `Email`, `PasswordHash`, `City`, `Country`, `Age`)
VALUES ('mike_jones', 'Mike', 'Jones', 'mike.jones@example.com', 'hashed_password_3', 'Los Angeles', 'USA',35);

INSERT INTO `Users` (`UserName`, `FirstName`, `LastName`, `Email`, `PasswordHash`, `City`, `Country`, `Age`)
VALUES ('sara_brown', 'Sara', 'Brown', 'sara.brown@example.com', 'hashed_password_4', 'Sydney', 'Australia', 28);

INSERT INTO `Users` (`UserName`, `FirstName`, `LastName`, `Email`, `PasswordHash`, `City`, `Country`, `Age`)
VALUES ('mark_wilson', 'Mark', 'Wilson', 'mark.wilson@example.com', 'hashed_password_5', 'Toronto', 'Canada', 32);

plan

-- User with UserID = 2 and SubscriptionID = 1
INSERT INTO `Plan` (`UserID`, `SubscriptionID`, `start_date`, `end_date`, `active_status`)
VALUES (2, 1, '2024-07-01', '2024-12-31', 1);

-- User with UserID = 3 and SubscriptionID = 2
INSERT INTO `Plan` (`UserID`, `SubscriptionID`, `start_date`, `end_date`, `active_status`)
VALUES (3, 2, '2024-07-01', '2024-12-31', 1);

-- User with UserID = 4 and SubscriptionID = 1
INSERT INTO `Plan` (`UserID`, `SubscriptionID`, `start_date`, `end_date`, `active_status`)
VALUES (4, 1, '2024-07-01', '2024-12-31', 1);

-- User with UserID = 5 and SubscriptionID = 2
INSERT INTO `Plan` (`UserID`, `SubscriptionID`, `start_date`, `end_date`, `active_status`)
VALUES (5, 2, '2024-07-01', '2024-12-31', 1);

-- User with UserID = 6 and SubscriptionID = 1
INSERT INTO `Plan` (`UserID`, `SubscriptionID`, `start_date`, `end_date`, `active_status`)
VALUES (6, 1, '2024-07-01', '2024-12-31', 1);



Category

INSERT INTO `Category` (`CategoryName`) VALUES ('drama');
INSERT INTO `Category` (`CategoryName`) VALUES ('comedy');
INSERT INTO `Category` (`CategoryName`) VALUES ('sci-fi');
INSERT INTO `Category` (`CategoryName`) VALUES ('action');
INSERT INTO `Category` (`CategoryName`) VALUES ('romantic');



VIDEO
-- Inserting a video for 'drama' (CategoryID = 1)
INSERT INTO `Video` (`Title`, `VideoDescription`, `Duration`, `ReleaseDate`, `Movie_OR_Show`, `CategoryID`)
VALUES ('The Shawshank Redemption', 'Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency.', 142, '1994-09-23', 1, 1);

-- Inserting a video for 'comedy' (CategoryID = 2)
INSERT INTO `Video` (`Title`, `VideoDescription`, `Duration`, `ReleaseDate`, `Movie_OR_Show`, `CategoryID`)
VALUES ('Superbad', 'Two co-dependent high school seniors are forced to deal with separation anxiety after their plan to stage a booze-soaked party goes awry.', 113, '2007-08-17', 1, 2);

-- Inserting a video for 'sci-fi' (CategoryID = 3)
INSERT INTO `Video` (`Title`, `VideoDescription`, `Duration`, `ReleaseDate`, `Movie_OR_Show`, `CategoryID`)
VALUES ('Inception', 'A thief who enters the dreams of others to steal secrets from their subconscious is offered a chance to have his criminal history erased as payment for implanting an idea into the mind of a CEO.', 148, '2010-07-16', 1, 3);

-- Inserting a video for 'action' (CategoryID = 4)
INSERT INTO `Video` (`Title`, `VideoDescription`, `Duration`, `ReleaseDate`, `Movie_OR_Show`, `CategoryID`)
VALUES ('Mad Max: Fury Road', 'In a post-apocalyptic wasteland, a woman rebels against a tyrannical ruler in search of her homeland with the aid of a group of female prisoners, a psychotic worshiper, and a drifter named Max.', 120, '2015-05-15', 1, 4);

-- Inserting a video for 'romantic' (CategoryID = 5)
INSERT INTO `Video` (`Title`, `VideoDescription`, `Duration`, `ReleaseDate`, `Movie_OR_Show`, `CategoryID`)
VALUES ('The Notebook', 'A poor yet passionate young man falls in love with a rich young woman, giving her a sense of freedom, but they are soon separated because of their social differences.', 123, '2004-06-25', 1, 5);



VideoActor

INSERT INTO `VideoActor` (`VideoID`, `ActorID`, `Role`)
VALUES
  (2, 1, 'comedian'),   
  (3, 2, 'hero'),   
  (4, 3, 'hero'),   
  (5, 4, 'heroine'), 
  (6, 5, 'heroine');
  


Review

INSERT INTO `Review` (`UserID`, `VideoID`, `Rating`, `Comment`)
VALUES
  (2, 2, 4, 'Great movie, loved the storyline.'),
  (3, 3, 5, 'Excellent performance by the actors!'),
  (4, 4, 3, 'Interesting plot but pacing was slow.'),
  (5, 5, 4, 'Action-packed and thrilling.'),
  (6, 6, 5, 'Beautifully shot and emotionally engaging.');



FAV LIST
INSERT INTO `FavoriteList` (`UserID`)
VALUES
  (2),
  (3),
  (4),
  (5),
  (6);



FAVOURITE LIST VIDEO

INSERT INTO `FavoriteListVideo` (`FavoriteListID`, `VideoID`)
VALUES
  (1, 5),   
  (1, 2),   
  (2, 3),  
  (2, 4); 


INSERT INTO `Watch_History` (`UserID`, `VideoID`, `WatchedDateTIme`, `WatchLength`)
VALUES 
     (2 ,  1,  '2024-07-01', 120),
     (3 ,  2,  '2024-07-02', 50),
     (4 ,  3,  '2024-07-03', 45)

